package icu.takeneko.gridmap.map;

public interface PositionedElement {

}
