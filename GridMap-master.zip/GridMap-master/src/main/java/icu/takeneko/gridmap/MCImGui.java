package icu.takeneko.gridmap;

import imgui.gl3.ImGuiImplGl3;
import imgui.glfw.ImGuiImplGlfw;

public class MCImGui {
    public static final String GLSL_VERSION = "#version 150";
    public static final ImGuiImplGlfw IMGUI_GLFW = new ImGuiImplGlfw();
    public static final ImGuiImplGl3 IMGUI_GL3 = new ImGuiImplGl3();
}
