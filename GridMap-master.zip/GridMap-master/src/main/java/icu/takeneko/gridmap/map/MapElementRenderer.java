package icu.takeneko.gridmap.map;

public interface MapElementRenderer {
}
